README - Datasets Exportés

1) dataset_final.csv / dataset_final.xlsx
   → version riche (complète) avec toutes les colonnes et métadonnées.

2) dataset_final_core.csv / dataset_final_core.xlsx
   → version épurée, ne garde que les colonnes principales :
      - iso3
      - year
      - population_total
      - gdp_current_usd
      - gdp_real_growth_pct
      - life_expectancy_years
      - maternal_mortality_ratio
